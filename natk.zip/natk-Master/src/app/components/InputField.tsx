import React from 'react';

interface InputFieldProps {
    type: string; // Тип поля ввода
    placeholder: string; // Текст-подсказка, который будет отображаться в поле ввода, когда оно пустое
    value: string; // Значение, которое отображается в поле ввода
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; // Функция обратного вызова для изменения значения поля
    bgColor?: string; // Цвет фона поля ввода (необязательный)
    textColor?: string; // Цвет текста в поле ввода (необязательный)
    className?: string; // Дополнительные классы для кастомизации компонента (необязательный)
}

const InputField: React.FC<InputFieldProps> = ({
    type,
    placeholder,
    value,
    onChange,
    bgColor = "bg-white", // Устанавливаем значение по умолчанию
    textColor = "text-gray-800", // Устанавливаем значение по умолчанию
    className,
}) => {
    return (
        <input
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            className={`
                ${bgColor} 
                ${textColor} 
                px-4 py-3 
                w-full 
                border 
                border-gray-200 
                focus:outline-none 
                focus:ring-2 
                focus:ring-blue-500 
                focus:border-transparent 
                shadow-sm 
                hover:shadow-md 
                transition-all 
                duration-200 
                ease-in-out 
                placeholder-gray-400 
                ${className}
            `}
        />
    );
};

export default InputField;