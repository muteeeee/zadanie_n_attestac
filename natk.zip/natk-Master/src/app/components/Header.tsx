'use client';

import React from 'react';


interface HeaderProps {
    systemName: string; // Название системы, которое будет отображаться в заголовке
    onLogout: () => void; // Функция для выхода из системы
    onToggleDarkMode: (isDarkMode: boolean) => void; // Функция для переключения темной темы
    onToggleReadingMode: (isReadingMode: boolean) => void; // Функция для переключения режима чтения
}

const Header: React.FC<HeaderProps> = ({
                                           systemName,
                                           onLogout,
                                           
                                       }) => {
    return (
        <header className="bg-blue-400 text-white p-4 flex justify-between items-center">
            {/* Логотип */}
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 relative">
                    <img src="/college-logo.png" alt="College Logo" className="w-12 h-12" />
                </div>
                {/* Название системы */}
                <h1 className="text-2xl font-bold">{systemName}</h1>
            </div>

            {/* Кнопка для выхода из системы */}
            <button
                onClick={onLogout} // Вызов функции onLogout при клике на кнопку
                className="bg-red-400 px-4 py-2 transition-transform duration-200 ease-in-out transform hover:scale-105"
            >
                Выйти
            </button>
        </header>
    );
};

export default Header;