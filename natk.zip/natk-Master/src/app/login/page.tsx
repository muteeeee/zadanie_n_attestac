'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';  // Навигация между страницами
import Button from '../components/Button';    // Компонент кнопки
import InputField from '../components/InputField'; // Компонент для ввода

const LoginPage = () => {
    const [username, setUsername] = useState(''); // Состояние для логина 
    const [password, setPassword] = useState(''); // Состояние для пароля
    const router = useRouter(); // Работа с навигацией

    // Обработка входа в систему
    const handleLogin = () => {
        // Проверка, при правильно введенных данных
        if (username === 'Admin' && password === 'pswrd') {
            // Перенаправление на главную страницу при успешном входе
            router.push('/home');
        } else {
            // Ошибка, если данные неправильные
            alert('Неверный логин или пароль');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
            {/* Контейнер с двумя колонками */}
            <div className="flex flex-col md:flex-row w-full max-w-6xl p-4">
                {/* Изображение слева */}
                <div className="hidden md:block w-1/2 pr-8">
                    <img 
                        src="/natk3.png" 
                        alt="NatK3 Image" 
                        className="w-full h-auto rounded-lg shadow-lg" 
                    />
                </div>
                {/* Форма авторизации справа */}
                <div className="bg-white p-8 shadow-sm border border-gray-100 w-full max-w-md md:w-1/2">
                    {/* Логотип колледжа */}
                    <div className="text-center mb-8">
                        <img 
                            src="/college-logo.png" 
                            alt="College Logo" 
                            className="w-24 h-24 mx-auto mb-4" 
                        />
                        <h1 className="text-2xl font-semibold text-gray-800">Авторизация</h1>
                        <p className="text-sm text-gray-500 mt-2">Введите свои данные для входа</p>
                    </div>
                    <div className="space-y-6">
                        {/* Поле ввода для логина */}
                        <InputField
                            type="text"
                            placeholder="Логин"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)} // Обновление состояния
                            bgColor="bg-gray-50"
                            textColor="text-gray-800"
                            className="w-full px-4 py-3 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                        />
                        {/* Поле ввода для пароля */}
                        <InputField
                            type="password"
                            placeholder="Пароль"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} // Обновление состояния
                            bgColor="bg-gray-50"
                            textColor="text-gray-800"
                            className="w-full px-4 py-3 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                        />
                        {/* Кнопка для отправки формы */}
                        <Button
                            onClick={handleLogin}  // Обработчик нажатия на кнопку
                            bgColor="bg-blue-600 hover:bg-blue-700"
                            textColor="text-white"
                            text="Войти"
                            className="w-full px-4 py-3  transition-colors duration-200 shadow-sm hover:shadow-md"
                        />
                        {/* Ссылки для восстановления пароля и регистрации */}
                        <div className="text-center mt-6 space-y-2">
                            <a href="#" className="text-sm text-blue-600 hover:text-blue-700 transition-colors">Забыли пароль?</a>
                            <br />
                            <a href="#" className="text-sm text-blue-600 hover:text-blue-700 transition-colors">Регистрация</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;