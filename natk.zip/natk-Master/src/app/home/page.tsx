'use client';
// Импорт модулей
import React, { useState } from 'react'; // Управление состоянием
import Header from '../components/Header'; // Компонент Header
import Footer from '../components/Footer'; // Компонент Footer
import Image from 'next/image'; // Компонент Image для оптимизированной загрузки изображений

// Основной компонент страницы HomePage
const HomePage = () => {
    // Состояние для управления темной темой
    const [isDarkMode, setIsDarkMode] = useState(false);
    // Состояние для управления режимом чтения
    const [isReadingMode, setIsReadingMode] = useState(false);

    // Функция для выхода из системы
    const handleLogout = () => {
        // Перенаправляем пользователя на страницу входа
        window.location.href = '/login';
    };

    return (
        // Основной контейнер страницы
        <div className={`flex flex-col min-h-screen ${isDarkMode ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'}`}>
            {/* Компонент Header */}
            <Header
                systemName="Натк" // Название системы
                onLogout={handleLogout} // Функция для выхода
                onToggleDarkMode={(checked) => setIsDarkMode(checked)} // Функция для переключения темной темы
                onToggleReadingMode={(checked) => setIsReadingMode(checked)} // Функция для переключения режима чтения
            />
            {/* Основное содержимое страницы */}
            <main className={`flex-grow p-8 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
                {/* Заголовок страницы */}
                <h1 className="text-5xl font-bold text-center mb-8 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                    История НАТК
                </h1>
                {/* Условный рендеринг: если режим чтения выключен, показываем изображения */}
                {!isReadingMode && (
                    <>
                        {/* Блок с изображением и подписью */}
                        <div className="flex flex-col items-center mb-12">
                            <div className="relative w-full max-w-2xl overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300">
                                <Image
                                    src="/natk.png" // Путь к изображению
                                    alt="Наши выпускники!!" // Альтернативный текст
                                    width={750} // Ширина изображения
                                    height={350} // Высота изображения
                                    className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-300"
                                />
                            </div>
                            <p className="mt-4 text-center text-xl text-gray-600 dark:text-gray-300">
                                Наши выпускники!!!
                            </p>
                        </div>
                        {/* Второй блок с изображением и подписью */}
                        <div className="flex flex-col items-center mb-12">
                            <div className="relative w-full max-w-2xl overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300">
                                <Image
                                    src="/natk2.png"
                                    alt="Колледж 2020 год"
                                    width={750}
                                    height={350}
                                    className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-300"
                                />
                            </div>
                            <p className="mt-4 text-center text-xl text-gray-600 dark:text-gray-300">
                                Пара в 2020 году
                            </p>
                        </div>
                    </>
                )}
                {/* Текстовый блок с историей колледжа */}
                <div className="max-w-4xl mx-auto space-y-8">
                    <p className="text-xl leading-relaxed text-gray-700 dark:text-gray-300">
                        Новосибирский авиационный технический колледж имени Б.С. Галущака начал свою историю в 1929 году как Новосибирский машиностроительный техникум, который был передан в подчинение Народного комиссариата тяжелой промышленности. В 1937 году он был переименован в авиационный техникум и стал готовить специалистов по конструированию и производству самолетов.
                        Во время Великой Отечественной войны многие учащиеся ушли на фронт, а оставшиеся работали в цехах авиационного завода имени В. П. Чкалова. После войны учебный процесс продолжился, и Учреждение перешло в ведение Министерства общего и профессионального образования Российской Федерации.
                        В 1966 году Новосибирский электромеханический техникум был переименован в Новосибирский авиационный техникум, а в 1991 году - в Новосибирский авиационный технический колледж. В 2007 году Учреждение стало одним из победителей Приоритетного национального проекта «Образование» с инновационной образовательной программой.
                        В 2015 году к Учреждению был присоединен Новосибирский приборостроительный техникум имени Б.С. Галущака, что позволило расширить спектр специальностей и направлений обучения. В 2020 году к Учреждению был присоединен Новосибирский радиотехнический колледж, что дало возможность открыть новые специальности и направления подготовки специалистов.
                    </p>
                    {/* Второй текстовый блок */}
                    <p className="text-xl leading-relaxed text-gray-700 dark:text-gray-300">
                        С 20 февраля 1931 г. Учреждение стало именоваться «Новосибирский техникум сельскохозяйственных машин», а с 8 апреля 1933 – «Новосибирский техникум машиностроения». В 1936-1937 гг. в Новосибирске на базе завода горного оборудования был создан авиационный завод. В ноябре 1937 с заводского аэродрома взлетел первый самолет.
                    </p>
                    {/* Третий текстовый блок */}
                    <p className="text-xl leading-relaxed text-gray-700 dark:text-gray-300">
                        7 марта 1991 г. решением Госкомитета СССР по народному образованию и Министерства авиационной промышленности (приказ Министерства авиационной промышленности СССР от 7 марта 1991 г. №478) Новосибирский авиационный техникум преобразован в Новосибирский авиационный технический колледж. В Учреждении осуществлялась трехуровневая система профессионального образования. Среди приоритетных направлений развития – сохранение и развитие лучших традиций, научная работа, компьютеризация.
                    </p>
                </div>
            </main>
            {/* Компонент Footer */}
            <Footer />
        </div>
    );
};

export default HomePage;